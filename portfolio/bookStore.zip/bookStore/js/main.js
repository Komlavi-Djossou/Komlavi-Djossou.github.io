'use strict';

import { openClose } from "./navBar.js";