'use strict';

import { openClose } from "./navBar.js";
import { getBooksBySubject } from './library.js';
import { appendData } from './library.js';

// DOM Element(s)

const subjectText = document.querySelector('#subject');
const getBooksButton = document.querySelector('#getBooks');
const getAuthorsName = document.querySelector('#myData');
const menu = document.getElementsByClassName('menu');

// Main

getBooksButton.addEventListener('click', () => {
  getBooksBySubject(subjectText.value);
});

getAuthorsName.addEventListener('click', () => {
  appendData(subjectText.value);
});

menu.addEventListener('click', openClose);
